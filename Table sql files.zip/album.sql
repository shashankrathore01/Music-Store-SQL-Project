CREATE TABLE album(
album_id VARCHAR(20) PRIMARY KEY,
title VARCHAR(100),
artist_id VARCHAR(20));

copy album(album_id, title, artist_id)
from 'D:\Music Playlist- SQL Project\album.csv'
delimiter ','
CSV header;

select * from album