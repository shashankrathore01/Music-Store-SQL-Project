CREATE TABLE media_type(
media_type_id VARCHAR(50) PRIMARY KEY,
name VARCHAR(30));

Copy media_type(media_type_id, name)
from 'D:\Music Playlist- SQL Project\media_type.csv'
delimiter ','
CSV header;

select* from media_type