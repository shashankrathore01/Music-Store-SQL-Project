CREATE TABLE genre(
genre_id VARCHAR(50) PRIMARY KEY,
name VARCHAR(30));

copy genre(genre_id, name)
from 'D:\Music Playlist- SQL Project\genre.csv'
delimiter ','
CSV header;

select * from genre