CREATE TABLE playlist(
playlist_id VARCHAR(50) PRIMARY KEY,
name VARCHAR(30));

copy playlist(playlist_id, name)
from 'D:\Music Playlist- SQL Project\playlist.csv'
delimiter ','
CSV header;

select * from playlist