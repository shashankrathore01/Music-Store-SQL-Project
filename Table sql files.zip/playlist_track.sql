CREATE TABLE playlist_track (
    playlist_id VARCHAR(50),
    track_id VARCHAR(50),
    PRIMARY KEY (playlist_id, track_id)
);

copy playlist_track(playlist_id, track_id)
from 'D:\Music Playlist- SQL Project\playlist_track.csv'
delimiter ','
CSV header;

select * from playlist_track