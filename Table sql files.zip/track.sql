CREATE TABLE track(
track_id INT PRIMARY KEY,
name VARCHAR(150),
album_id VARCHAR(30),
media_type_id VARCHAR(30),
genre_id VARCHAR(30),
composer VARCHAR(500),
milliseconds INTEGER,
bytes BIGINT,
unit_price NUMERIC(5,2));

COPY track(track_id, name, album_id, media_type_id, genre_id, composer, milliseconds, bytes, unit_price)
FROM 'D:\Music Playlist- SQL Project\track.csv'
DELIMITER ','
CSV HEADER;

select* from track
