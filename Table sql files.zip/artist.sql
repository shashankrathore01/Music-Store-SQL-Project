CREATE TABLE artist(
artist_id VARCHAR(30) PRIMARY KEY,
name  VARCHAR(100));

copy artist(artist_id, name)
from 'D:\Music Playlist- SQL Project\artist.csv'
delimiter ','
CSV header;

select * from artist