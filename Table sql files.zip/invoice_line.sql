CREATE TABLE invoice_line(
invoice_line_id INT PRIMARY KEY,
invoice_id INT,
track_id INT,
unit_price DECIMAL(5, 2),
quantity INT);

copy invoice_line(invoice_line_id, invoice_id, track_id,
unit_price, quantity)
from 'D:\Music Playlist- SQL Project\invoice_line.csv'
delimiter ','
CSV header;

select * from invoice_line