CREATE TABLE invoice(
invoice_id INT PRIMARY KEY,
customer_id VARCHAR(30),
invoice_date TIMESTAMP,
billing_address VARCHAR(120),
billing_city VARCHAR(30),
billing_state VARCHAR(30),
billing_country VARCHAR(30),
billing_postal VARCHAR(30),
total FLOAT8);

copy invoice(invoice_id, customer_id, invoice_date, billing_address,
billing_city, billing_state, billing_country, billing_postal, total)
from 'D:\Music Playlist- SQL Project\invoice.csv'
delimiter ','
CSV header;

select * from invoice