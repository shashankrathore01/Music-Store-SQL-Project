CREATE TABLE employee(
employee_id VARCHAR(50) PRIMARY KEY,
last_name CHAR(50),
first_name CHAR(50),
title VARCHAR(50),
reports_to VARCHAR(30),
levels VARCHAR(10),
birthdate TIMESTAMP,
hire_date TIMESTAMP,
address VARCHAR(120),
city VARCHAR(50),
state VARCHAR(50),
country VARCHAR(30),
postal_code VARCHAR(30),
phone VARCHAR(30),
fax VARCHAR(30),
email VARCHAR(30));

INSERT INTO employee
(employee_id, last_name, first_name, title, reports_to, levels, birthdate, hire_date, address, city, state, country, postal_code, phone, fax, email)
Values
('1', 'Adams', 'Andrew', 'General Manager', 'NULL', 'L6', '1962-02-18', '2016-08-14', '11120 Jasper Ave NW', 'Edmonton', 'AB', 'Canada', 'T5K 2N1', '+1 (780) 428-9482', '+1 (780) 428-3457', 'andrew@chinookcorp.com'),
('2', 'Edwards', 'Nancy', 'Sales Manager', '1', 'L5', '1958-12-08', '2017-05-01', '825 8 Ave SW', 'Calgary', 'AB', 'Canada', 'T2P 2T3', '+1 (403) 262-3443', '+1 (403) 262-3322', 'nancy@chinookcorp.com'),
('3', 'Peacock', 'Jane', 'Sales Support Agent', '2', 'L1', '1973-08-29', '2017-08-14', '1111 6 Ave SW', 'Calgary', 'AB', 'Canada', 'T2P 5M5', '+1 (403) 262-3443', '+1 (403) 262-6712', 'jane@chinookcorp.com'),
('4', 'Park', 'Margaret', 'Sales Support Agent', '2', 'L1', '1947-09-19', '2017-08-14', '683 10 Street SW', 'Calgary', 'AB', 'Canada', 'T2P 5G3', '+1 (403) 263-4423', '+1 (403) 263-4289', 'margaret@chinookcorp.com'),
('5', 'Johnson', 'Steve', 'Sales Support Agent', '2', 'L1', '1965-03-03', '2017-08-14', '7727 8 Street SW', 'Calgary', 'AB', 'Canada', 'T2P 4G8', '+1 (403) 256-3563', '+1 (403) 256-9988', 'steve@chinookcorp.com'),
('6', 'Mitchell', 'Michael', 'IT Manager', '1', 'L4', '1973-07-01', '2017-10-17', '5827 Bowness Road NW', 'Calgary', 'AB', 'Canada', 'T3B 0C5', '+1 (403) 247-9982', '+1 (403) 247-9937', 'michael@chinookcorp.com'),
('7', 'King', 'Robert', 'IT Staff', '6', 'L2', '1970-05-29', '2017-10-17', '590 Columbia Boulevard W', 'Lethbridge', 'AB', 'Canada', 'T1K 5N8', '+1 (403) 456-9982', '+1 (403) 456-8485', 'robert@chinookcorp.com'),
('8', 'Callahan', 'Laura', 'IT Staff', '6', 'L2', '1968-01-09', '2017-10-17', '9227 5 Street SE', 'Calgary', 'AB', 'Canada', 'T2J 3L5', '+1 (403) 456-9983', '+1 (403) 456-8486', 'laura@chinookcorp.com'),
('9', 'Griffin', 'Amy', 'Finance Manager', '1', 'L4', '1972-10-14', '2017-10-17', '2455 Plywood Ave', 'Calgary', 'AB', 'Canada', 'T2P 7G4', '+1 (403) 890-9982', '+1 (403) 890-9983', 'amy@chinookcorp.com');

